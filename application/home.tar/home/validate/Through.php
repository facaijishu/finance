<?php

namespace app\home\validate;

use think\Validate;

class Through extends Validate
{
    protected $rule = [
        ['realname', 'require', '请输入姓名'],
        ['phone', 'require|length:11,11', '请输入手机号|手机号不正确'],
        //['email', 'require|email', '请输入联系邮箱|邮箱格式不正确'],
        //['company', 'require', '请输入公司名称'],
        //['position', 'require', '请输入职位'],
//        ['card', 'require', '请上传名片'],
    ];

    protected $scene = [
        'add'   => ['realname','phone','email','company','position'],
        'edit'   => ['realname','phone','email','company','position'],
    ];
}