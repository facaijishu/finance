<?php

namespace app\home\model;

use think\Model;

class Spoiler extends Model
{
    public function getSpoilerInfo($id){
        $result = $this->where(['sp_id' => $id])->find();
        $img = $result['img'];
        if($img != ''){
            $arr_img = [];
            $arr = explode(',', $img);
            $model = model("MaterialLibrary");
            $result['img_length'] = count($arr);
            if ($result['img_length'] === 1){
                $info = $model->getMaterialInfoById($arr[0]);
                $result['img'] = $info['url'];
            } else {
                foreach ($arr as $key1 => $value1) {
                    $info = $model->getMaterialInfoById($value1);
                    $arr[$key1] = $info['url_thumb'];
                    $arr_img[$key1] = $info['url'];
                }
                $result['img'] = $arr;
                $result['img_url'] = $arr_img;
            }
        }
        $thumbs_up = $result['thumbs_up'];
        if($thumbs_up != ''){
            $arr = explode(',', $thumbs_up);
            $result['thumbs_up'] = $arr;
            $model = model("Member");
            foreach ($arr as $key1 => $value1) {
                $info = $model->getMemberInfoById($value1);
                $arr[$key1] = $info['userPhoto'];
            }
            $result['thumbs_up_img'] = $arr;
        }
        $model = model("SpoilerComments");
        $list = [];
        $list = $model->getSpoilerCommentsList($result['sp_id']);
        if(!empty($list)){
            foreach ($list as $key => $value) {
                $list[$key]['list'] = $model->getSpoilerCommentsList($value['sp_id'] , $value['spc_id']);
            }
        }
        $result['comments'] = $list;
        return $result;
    }
    public function getSpoilerList($id = 0 , $num = 0){
        $num = $num== 0 ? config("ins_num") : $num;
        $result = [];
        if($id == 0){
            $result = $this->where(['status' => 1])->order("release_date desc,create_time desc")->limit($num)->select();
        } else {
            $result = $this->where(['status' => 1])->where('sp_id','lt',$id)->order("release_date desc,create_time desc")->limit($num)->select();
        }
        if(!empty($result)){
            //出去列表页二添加
            foreach ($result as $key => $value) {
                $result[$key] = $this->getSpoilerInfo($value['sp_id']);
            }
        }
        return $result;
    }
    public function createThumbsUp($id){
        if(empty($id)){
            $this->error = '剧透id不存在';
            return false;
        }
        
        //开启事务
        $this->startTrans();
        try{
            $info = $this->where(['sp_id' => $id])->find();
            $arr = explode(',', $info['thumbs_up']);
            if(in_array(session('FINANCE_USER.uid'), $arr)){
                $this->error = '不可重复点赞';
                return false;
            } else {
                array_push($arr, session('FINANCE_USER.uid'));
                $thumbs_up = trim(implode(',', $arr) , ',');
                $this->where(['sp_id' => $id])->update(['thumbs_up' => $thumbs_up]);
            }
                // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
}