<?php

namespace app\home\model;

use think\Model;

class Order extends Model
{
    public function getOrderListByUser(){
        $user = session('FINANCE_USER');
        $list = $this->where(['uid' => $user['uid']])->select();
        if ((!empty($list))){
            foreach ($list as $key => $value) {
                $list[$key]['total_fee'] = floatval($value['total_fee']/100);
            }
        }
        return $list;
    }
}