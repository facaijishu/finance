<?php

namespace app\home\model;

use think\Model;

class Conversation extends Model
{
    
}