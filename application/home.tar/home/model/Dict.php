<?php

namespace app\home\model;

use think\Model;

class Dict extends Model
{
    public function getDictInfoById($id){
        if(empty($id)){
            $this->error = '该数据id不存在';
            return false;
        }
        $info = $this->where(['id' => $id])->find();
        return $info;
    }
    public function getDictByType($str = ''){
        if($str == ''){
            $this->error = '该数据类型名称不存在';
            return false;;
        }
        $result = $this->alias("d")
                ->join("dict_type dt" , "d.dt_id=dt.dt_id")
                ->where(['dt.sign' => $str])
                ->order("id")
                ->select();
        return $result;
    }
}