<?php

namespace app\home\model;

use think\Model;

class Activity extends Model
{
    public function getActivityInfo($id){
        $info = $this->where(['a_id' => $id])->find();
        $model = model("MaterialLibrary");
        $top_img = $model->getMaterialInfoById($info['top_img']);
        $info['top_img_url'] = $top_img['url'];
        $info['top_img_name'] = $top_img['name'];
        return $info;
    }
    public function getActivityListByUser($str){
        $arr = explode(',', $str);
        foreach ($arr as $key => $value) {
            $info = $this->getActivityInfo($value);
            $arr[$key] = $info;
        }
        return $arr;
    }

    public function getActivityList(){
        $result = $this->where(['is_use' => 1 , 'is_show' => 1])->where("status","neq",4)->order("list_order desc")->select();
        $model = model("MaterialLibrary");
        foreach ($result as $key => $value) {
            $time = date('Y-m-d H:i' , time());
			if($value['status'] != 2){
				if($value['status'] == 0){
					if($time > $value['start_time']){
						if($time > $value['end_time']){
							$state = 2;
						} else {
							$state = 1;
						}
						$result[$key]['status'] = $state;
						model("Activity")->where(['a_id' => $value['a_id']])->update(['status' => $state]);
					}elseif ($time > $value['end_time']) {
						$state = 2;
						$result[$key]['status'] = $state;
						model("Activity")->where(['a_id' => $value['a_id']])->update(['status' => $state]);
					}
				}elseif ($value['status'] == 1) {
					if($time > $value['end_time']){
						$state = 2;
						$result[$key]['status'] = $state;
						model("Activity")->where(['a_id' => $value['a_id']])->update(['status' => $state]);
					}
				}
			}			
            $top_img = $model->getMaterialInfoById($value['top_img']);
            $result[$key]['top_img_url'] = $top_img['url'];
        }
        return $result;
    }
    public function setCollection($id , $sign){
        if(empty($id)){
            $this->error = '活动id不存在';
            return false;
        }
        if(empty($sign)){
            $this->error = '缺少收藏标签sign';
            return false;
        }
        //开启事务
        $this->startTrans();
        try{
            $arr = [];
            $user = session("FINANCE_USER");
            $collection = explode(',', $user['collection_activity']);
            if($sign == 'true'){
                if(in_array($id, $collection)){
                    $this->error = '该项目已收藏,不能重复收藏';
                    return false;
                } else {
                    array_push($collection, $id);
                    $coll = trim(implode(',', $collection) , ',');
                    $model = model("Member");
                    $model->where(['uid' => $user['uid']])->update(['collection_activity' => $coll]);
                    $user = $model->where(['uid' => $user['uid']])->find();
                    session('FINANCE_USER' , $user);
                }
            } else {
                if(in_array($id, $collection)){
                    foreach ($collection as $key => $value) {
                        if($value == $id){
                            unset($collection[$key]);
                        }
                    }
                    $coll = trim(implode(',', $collection) , ',');
                    $model = model("Member");
                    $model->where(['uid' => $user['uid']])->update(['collection_activity' => $coll]);
                    $user = $model->where(['uid' => $user['uid']])->find();
                    session('FINANCE_USER' , $user);
                } else {
                    $this->error = '该项目未收藏,不能取消收藏';
                    return false;
                }
            }
            // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
}