<?php

namespace app\home\model;

use think\Model;

class Consultation extends Model
{
    public function getConsultationInfoById($id){
        $result = $this->where(['con_id' => $id])->find();
        $model = model("User");
        $user = $model->getUserInfoById($result['create_uid']);
        $result['create_uid'] = $user['real_name'];
        $result['time'] = substr($result['create_time'], 5, 11);
        return $result;
    }

    public function getConsultationList($length = 0){
        if($length === 0){
            $result = $this->alias('con')
                    ->join("dict d" , 'con.type = d.id')
                    ->where(['con.status' => 1 , 'd.des' => ''])
                    ->order("is_hot desc,con_id desc")
                    ->select();
        } else {
            $result = $this->alias('con')
                    ->join("dict d" , 'con.type = d.id')
                    ->where(['con.status' => 1 , 'd.des' => ''])
                    ->order("is_hot desc,con_id desc")
                    ->limit($length)
                    ->select();
        }
        $model = model("MaterialLibrary");
        foreach ($result as $key => $value) {
            $top_img = $model->getMaterialInfoById($value['top_img']);
            $result[$key]['top_img'] = $top_img['url'];
            $result[$key]['top_img_compress'] = $top_img['url_compress'];
        }
        return $result;
    }
    public function getConsultationNoticeList(){
        $result = $this->alias('con')
                    ->join("dict d" , 'con.type = d.id')
                    ->where(['con.status' => 1 , 'd.des' => 'notice'])
                    ->order("is_hot desc,con_id desc")
                    ->select();
            return $result;
    }
}