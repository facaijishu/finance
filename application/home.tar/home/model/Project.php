<?php

namespace app\home\model;

use think\Model;

class Project extends Model
{
    public function getProjectLimitList($length){
        $result = $this->where(['status' => 2 , 'flag' => 1])->order("list_order desc")->limit($length)->select();
        foreach ($result as $key => $value) {
            $inc_industry = explode(',', $value['inc_industry']);
            $model = model("dict");
            $transfer_type = $model->getDictInfoById($value['transfer_type']);
            $result[$key]['transfer_type'] = $transfer_type['value'];
            $capital_plan = $model->getDictInfoById($value['capital_plan']);
            $result[$key]['capital_plan'] = $capital_plan['value'];
            $hierarchy = $model->getDictInfoById($value['hierarchy']);
            $result[$key]['hierarchy'] = $hierarchy['value'];
            foreach ($inc_industry as $key1 => $value1) {
                $info = $model->getDictInfoById($value1);
                $inc_industry[$key1] = $info['value'];
            }
            $result[$key]['inc_industry'] = $inc_industry;
            $model = model("material_library");
            $top_img = $model->getMaterialInfoById($value['top_img']);
            $result[$key]['top_img'] = $top_img['url'];
            $result[$key]['top_img_compress'] = $top_img['url_compress'];
            $company_video = $model->getMaterialInfoById($value['company_video']);
            $result[$key]['company_video'] = $company_video['url'];
        }
        return $result;
    }

    //获取简单的项目信息
    public function getProjectSimpleInfoById($id){
        if(empty($id)){
            $this->error = '该项目ID不存在';
            return false;
        }
        $info = $this->where(['pro_id' => $id])->find();
        $erweima = db("qrcode_direction")->where(['id' => $info['qr_code']])->find();
        $info['qr_code'] = $erweima['qrcode_path'];
        $inc_industry = explode(',', $info['inc_industry']);
        $model = model("material_library");
        $top_img = $model->getMaterialInfoById($info['top_img']);
        $info['top_img'] = $top_img['url'];
        $model = model("dict");
        $transfer_type = $model->getDictInfoById($info['transfer_type']);
        $info['transfer_type'] = $transfer_type['value'];
        $hierarchy = $model->getDictInfoById($info['hierarchy']);
        $info['hierarchy'] = $hierarchy['value'];
        foreach ($inc_industry as $key1 => $value1) {
            $result = $model->getDictInfoById($value1);
            $inc_industry[$key1] = $result['value'];
        }
        $info['inc_industry'] = $inc_industry;
        return $info;
    }
    //获取完整的项目信息
    public function getProjectInfoById($id){
        if(empty($id)){
            $this->error = '该项目ID不存在';
            return false;
        }
        $info = $this->where(['pro_id' => $id])->find();
        $inc_industry = explode(',', $info['inc_industry']);
        $model = model("dict");
        $qa_type = $model->getDictByType("qa_type");
        $info['qa_type'] = $qa_type;
        $transfer_type = $model->getDictInfoById($info['transfer_type']);
        $info['transfer_type'] = $transfer_type['value'];
        $hierarchy = $model->getDictInfoById($info['hierarchy']);
        $info['hierarchy'] = $hierarchy['value'];
        foreach ($inc_industry as $key1 => $value1) {
            $result = $model->getDictInfoById($value1);
            $inc_industry[$key1] = $result['value'];
        }
        $info['inc_industry'] = $inc_industry;
        if($info['investment_lights'] != ''){
            $str = preg_replace('/\n/', '<br>', $info['investment_lights']);
            $investment_lights = explode('<br>', $str);
            $info['investment_lights'] = $investment_lights;
        } else {
            $info['investment_lights'] = [];
        }
        if($info['enterprise_des'] != ''){
            $str = preg_replace('/\n/', '<br>', $info['enterprise_des']);
            $enterprise_des = explode('<br>', $str);
            $info['enterprise_des'] = $enterprise_des;
        } else {
            $info['enterprise_des'] = [];
        }
        if($info['company_des'] != ''){
            $str = preg_replace('/\n/', '<br>', $info['company_des']);
            $company_des = explode('<br>', $str);
            $info['company_des'] = $company_des;
        } else {
            $info['company_des'] = [];
        }
        if($info['product_des'] != ''){
            $str = preg_replace('/\n/', '<br>', $info['product_des']);
            $product_des = explode('<br>', $str);
            $info['product_des'] = $product_des;
        } else {
            $info['product_des'] = [];
        }
        if($info['analysis_des'] != ''){
            $str = preg_replace('/\n/', '<br>', $info['analysis_des']);
            $analysis_des = explode('<br>', $str);
            $info['analysis_des'] = $analysis_des;
        } else {
            $info['analysis_des'] = [];
        }
        $model = model("ProjectNews");
        $project_news = $model->getProjectNewsList($id);
        
        $model = model("ProjectQa");
        $project_qa = $model->getProjectQaList($id);
        $info['project_qa'] = $project_qa;
        
        $model = model("material_library");
        foreach ($project_news as $key => $value) {
            $top_img = $model->getMaterialInfoById($value['top_img']);
            $project_news[$key]['top_img'] = $top_img['url'];
            $project_news[$key]['time'] = substr($value['create_time'], 0, 10);
        }
        $info['project_news'] = $project_news;
        $top_img = $model->getMaterialInfoById($info['top_img']);
        $info['top_img'] = $top_img['url'];
        
        $arr = [];
        if($info['enterprise_url'] != ''){
            $enterprise_url = explode(',', $info['enterprise_url']);
            foreach ($enterprise_url as $key => $value) {
                $img = $model->getMaterialInfoById($value);
                array_push($arr, $img['url']);
            }
        }
        $info['enterprise_url'] = $arr;
        $arr = [];
        if($info['company_url'] != ''){
            $company_url = explode(',', $info['company_url']);
            foreach ($company_url as $key => $value) {
                $img = $model->getMaterialInfoById($value);
                array_push($arr, $img['url']);
            }
        }
        $info['company_url'] = $arr;
        $arr = [];
        if($info['product_url'] != ''){
            $product_url = explode(',', $info['product_url']);
            foreach ($product_url as $key => $value) {
                $img = $model->getMaterialInfoById($value);
                array_push($arr, $img['url']);
            }
        }
        $info['product_url'] = $arr;
        $arr = [];
        if($info['analysis_url'] != ''){
            $analysis_url = explode(',', $info['analysis_url']);
            foreach ($analysis_url as $key => $value) {
                $img = $model->getMaterialInfoById($value);
                array_push($arr, $img['url']);
            }
        }
        $info['analysis_url'] = $arr;
        
        $business_plan = $model->getMaterialInfoById($info['business_plan']);
        $info['business_plan'] = $business_plan['name'];
        $info['business_plan_url'] = $business_plan['url'];
        $factor_table = $model->getMaterialInfoById($info['factor_table']);
        $info['factor_table'] = $factor_table['name'];
        $info['factor_table_url'] = $factor_table['url'];
        $company_video = $model->getMaterialInfoById($info['company_video']);
        $info['company_video'] = $company_video['name'];
        $info['company_video_url'] = $company_video['url'];
        return $info;
    }
    //获取项目列表
    public function getProjectList($type = 2 , $sign = ''){
        if($sign != ''){
            $where = "`status` = 2 and `flag` = 1 and `inc_sign` like '%".$sign."%'";
        } else {
            $where = '`status` = 2 and `flag` = 1';
        }
        $result = $this->where($where)->order("list_order desc")->select();
        foreach ($result as $key => $value) {
            $inc_industry = explode(',', $value['inc_industry']);
            $model = model("dict");
            $transfer_type = $model->getDictInfoById($value['transfer_type']);
            $result[$key]['transfer_type'] = $transfer_type['value'];
            $hierarchy = $model->getDictInfoById($value['hierarchy']);
            $result[$key]['hierarchy'] = $hierarchy['value'];
            foreach ($inc_industry as $key1 => $value1) {
                $info = $model->getDictInfoById($value1);
                $inc_industry[$key1] = $info['value'];
            }
            $result[$key]['inc_industry'] = $inc_industry;
            $model = model("material_library");
            $top_img = $model->getMaterialInfoById($value['top_img']);
            $result[$key]['top_img'] = $top_img['url'];
            $company_video = $model->getMaterialInfoById($value['company_video']);
            $result[$key]['company_video'] = $company_video['url'];
        }
        return $result;
    }
    public function getProjectListByName($text){
        if(empty($text)){
            $result = $this->where('status = 2 and flag = 1')->select();
        } else {
            $result = $this->where('pro_name like "%'.$text.'%" and status = 2 and flag = 1')->select();
        }
        foreach ($result as $key => $value) {
            $inc_industry = explode(',', $value['inc_industry']);
            $model = model("dict");
            $transfer_type = $model->getDictInfoById($value['transfer_type']);
            $result[$key]['transfer_type'] = $transfer_type['value'];
            $hierarchy = $model->getDictInfoById($value['hierarchy']);
            $result[$key]['hierarchy'] = $hierarchy['value'];
            foreach ($inc_industry as $key1 => $value1) {
                $info = $model->getDictInfoById($value1);
                $inc_industry[$key1] = $info['value'];
            }
            $result[$key]['inc_industry'] = $inc_industry;
            $model = model("material_library");
            $top_img = $model->getMaterialInfoById($value['top_img']);
            $result[$key]['top_img'] = $top_img['url'];
            $company_video = $model->getMaterialInfoById($value['company_video']);
            $result[$key]['company_video'] = $company_video['url'];
        }
        return $result;
    }

    //获取收藏的项目列表
    public function getCollectionProjectList($collection){
        if(!empty($collection)){
            $collection = explode(',', $collection);
            $result = [];
            foreach ($collection as $key => $value) {
                $project = $this->where(['pro_id' => $value])->find();
                $model = model("dict");
                $transfer_type = $model->getDictInfoById($project['transfer_type']);
                $project['transfer_type'] = $transfer_type['value'];
                $hierarchy = $model->getDictInfoById($project['hierarchy']);
                $project['hierarchy'] = $hierarchy['value'];
                $inc_industry = explode(',', $project['inc_industry']);
                foreach ($inc_industry as $key1 => $value1) {
                    $info = $model->getDictInfoById($value1);
                    $inc_industry[$key1] = $info['value'];
                }
                $project['inc_industry'] = $inc_industry;
                
                $model = model("material_library");
                $top_img = $model->getMaterialInfoById($project['top_img']);
                $project['top_img'] = $top_img['url'];
                array_push($result, $project);
            }
        } else {
            $result = '';
        }
        return $result;
    }
	//新增的代码部分@param:2018/6/12 功能：企业的财报
	public function getProjectInfo($id){
        if(empty($id)){
            $this->error = '该项目ID不存在';
            return false;
        }
        $info = $this->where(['pro_id' => $id])->find();
		$info['neeq'] = $info['stock_code'];
        $gszls = db("gszls")->where(['neeq' => $info['neeq']])->find();
        $info['gszls'] = $gszls;
        $gdyjs_date = db("gdyjs")->where(['neeq' => $info['neeq']])->group("jzrq desc")->field("jzrq")->select();
		
        if(!empty($gdyjs_date)){
            $gdyjs = db("gdyjs")->where(['neeq' => $info['neeq'] , 'jzrq' => $gdyjs_date[0]['jzrq']])->limit(10)->select();
			
        } else {
            $gdyjs = [];
        }
		
        $cgsl_num = 0;$cgbl_num = 0;
        if(!empty($gdyjs)){
            foreach ($gdyjs as $key => $value) {
                $cgsl_num = intval($cgsl_num) + intval($value['cgsl']);
                $cgbl_num = floatval($cgbl_num) + floatval($value['cgbl']);
            }
        }
		//占比
		if(!empty($gszls['zgbwg'])){
			foreach($gdyjs as $key=>$value){
				$gdyjs[$key]['fen'] = round(floatval($gdyjs[$key]['cgsl']/(preg_replace('/,*/','',$gszls['zgbwg'])*10000)),4)*100;
			}
		}else{
			foreach($gdyjs as $key=>$value){
				$gdyjs[$key]['fen'] = '';
			}
		}
        $info['gdyjs'] = $gdyjs;
        $info['gdyjs_num'] = count($gdyjs);
        $info['cgsl_num'] = $cgsl_num;
        $info['cgbl_num'] = $cgbl_num;
        $ggzls = db("ggzls")->where(['neeq' => $info['neeq']])->where("deleted_at is null")->select();
        $info['ggzls'] = $ggzls;
        $gonggaos = db("st_gonggaos")->alias("gg")
//                ->join("StGonggaosStatus ggs" , "gg.ggid=ggs.ggid" , "LEFT")
                ->join("StSceus s" , "gg.ggid=s.ggid")
                ->where("s.secu_link_code","eq",$info['neeq'])
//                ->where("ggs.examine","eq",1)
                ->field("gg.*,s.secu_s_name")
                ->select();
        $info['gonggaos'] = $gonggaos;
        $yanbaos = db("st_yanbaos_effect")->where("relation","like","%".$info['neeq']."%")->select();
        $info['yanbaos'] = $yanbaos;
        //利润树状图
        $lirun = db("cwbbsjs")->where(['neeq' => $info['neeq'] , 'type' => 1 , 'bbxm' => 'NETPROFIT'])->field("bbrq,xmsz")->order("bbrq asc")->select();
        $lirun_bi = db("cwbbsjs")->where(['neeq' => $info['neeq'] , 'type' => 3 , 'bbxm' => 'PROFIT_YOY'])->field("bbrq,xmsz")->order("bbrq asc")->select();
        if(!empty($lirun) && !empty($lirun_bi)){
            foreach ($lirun as $key => $value) {
                foreach ($lirun_bi as $key1 => $value1) {
                    if($value1['bbrq'] == $value['bbrq']){
                        $lirun[$key]['lirun_bi'] = $value1['xmsz'];
                    }
                }
            }
        } else {
            foreach ($lirun as $key => $value) {
                $lirun[$key]['lirun_bi'] = '-';
            }
        }
		
        $arr = $this->getDataAndBi($lirun, $lirun_bi);
        $info['lirun'] = $arr[0];
        $info['lirun_bi'] = $arr[1];
        //营业收入树状图
        $shouru = db("cwbbsjs")->where(['neeq' => $info['neeq'] , 'type' => 1 , 'bbxm' => 'OPERATEREVE'])->field("bbrq,xmsz")->order("bbrq asc")->select();
        $shouru_bi = db("cwbbsjs")->where(['neeq' => $info['neeq'] , 'type' => 3 , 'bbxm' => 'revenue_YOY'])->field("bbrq,xmsz")->order("bbrq asc")->select();
        if(!empty($shouru) && !empty($shouru_bi)){
            foreach ($shouru as $key => $value) {
                foreach ($shouru_bi as $key1 => $value1) {
                    if($value1['bbrq'] == $value['bbrq']){
                        $shouru[$key]['shouru_bi'] = $value1['xmsz'];
                    }
                }
            }
        } else {
            foreach ($shouru as $key => $value) {
                $shouru[$key]['shouru_bi'] = '-';
            }
        }
        $arr = $this->getDataAndBi($shouru, $shouru_bi);
        $info['shouru'] = $arr[0];
        $info['shouru_bi'] = $arr[1];
        //每股净资产树状图
        $zichan = db("cwbbsjs")->where(['neeq' => $info['neeq'] , 'type' => 3 , 'bbxm' => 'BPS'])->field("bbrq,xmsz")->order("bbrq asc")->select();
        $zichan_bi = [];
        foreach ($zichan as $key => $value) {
            if($key == 0){
                array_push($zichan_bi, ['bbrq' => $value['bbrq'] , 'xmsz' => 0]);
                $zichan[$key]['zichan_bi'] = 0;
            } else {
                if(floatval($zichan[$key-1]['xmsz'] == 0)){
                    $val = 0;
                } else {
                    $val = (floatval($value['xmsz'])-floatval($zichan[$key-1]['xmsz']))/floatval($zichan[$key-1]['xmsz']);
                    $val = round(floatval($val), 2);
                }
                array_push($zichan_bi, ['bbrq' => $value['bbrq'] , 'xmsz' => $val]);
                $zichan[$key]['zichan_bi'] = $val;
            }
        }
        $arr = $this->getDataAndBi($zichan, $zichan_bi);
        $info['zichan'] = $arr[0];
        $info['zichan_bi'] = $arr[1];
        //每股现金流树状图
        $xianjinliu = db("cwbbsjs")->where(['neeq' => $info['neeq'] , 'type' => 3 , 'bbxm' => 'CFPS'])->field("bbrq,xmsz")->order("bbrq asc")->select();
        $xianjinliu_bi = [];
        foreach ($xianjinliu as $key => $value) {
            if($key == 0){
                array_push($xianjinliu_bi, ['bbrq' => $value['bbrq'] , 'xmsz' => 0]);
                $xianjinliu[$key]['xianjinliu_bi'] = 0;
            } else {
                if(floatval($xianjinliu[$key-1]['xmsz'] == 0)){
                    $val = 0;
                } else {
                    $val = (floatval($value['xmsz'])-floatval($xianjinliu[$key-1]['xmsz']))/floatval($xianjinliu[$key-1]['xmsz']);
                    $val = round(floatval($val), 2);
                }
                array_push($xianjinliu_bi, ['bbrq' => $value['bbrq'] , 'xmsz' => $val]);
                $xianjinliu[$key]['xianjinliu_bi'] = $val;
            }
        }
        $arr = $this->getDataAndBi($xianjinliu, $xianjinliu_bi);
        $info['xianjinliu'] = $arr[0];
        $info['xianjinliu_bi'] = $arr[1];
        //毛利率树状图
        $maolilv = db("cwbbsjs")->where(['neeq' => $info['neeq'] , 'type' => 3 , 'bbxm' => 'GROSSPROFITMARGIN'])->field("bbrq,xmsz")->order("bbrq asc")->select();
        $maolilv_bi = [];
        foreach ($maolilv as $key => $value) {
            if($key == 0){
                array_push($maolilv_bi, ['bbrq' => $value['bbrq'] , 'xmsz' => 0]);
                $maolilv[$key]['maolilv_bi'] = 0;
            } else {
                if(floatval($maolilv[$key-1]['xmsz'] == 0)){
                    $val = 0;
                } else {
                    $val = (floatval($value['xmsz'])-floatval($maolilv[$key-1]['xmsz']))/floatval($maolilv[$key-1]['xmsz']);
                    $val = round(floatval($val), 2);
                }
                array_push($maolilv_bi, ['bbrq' => $value['bbrq'] , 'xmsz' => $val]);
                $maolilv[$key]['maolilv_bi'] = $val;
            }
        }
        $arr = $this->getDataAndBi($maolilv, $maolilv_bi);
        $info['maolilv'] = $arr[0];
        $info['maolilv_bi'] = $arr[1];
        //每股收益树状图
        $shouyi = db("cwbbsjs")->where(['neeq' => $info['neeq'] , 'type' => 1 , 'bbxm' => 'BASICEPS'])->field("bbrq,xmsz")->order("bbrq asc")->select();
        $shouyi_bi = [];
        foreach ($shouyi as $key => $value) {
            if($key == 0){
                array_push($shouyi_bi, ['bbrq' => $value['bbrq'] , 'xmsz' => 0]);
                $shouyi[$key]['shouyi_bi'] = 0;
            } else {
                if(floatval($shouyi[$key-1]['xmsz'] == 0)){
                    $val = 0;
                } else {
                    $val = (floatval($value['xmsz'])-floatval($shouyi[$key-1]['xmsz']))/floatval($shouyi[$key-1]['xmsz']);
                    $val = round(floatval($val), 2);
                }
                array_push($shouyi_bi, ['bbrq' => $value['bbrq'] , 'xmsz' => $val]);
                $shouyi[$key]['shouyi_bi'] = $val;
            }
        }
        $arr = $this->getDataAndBi($shouyi, $shouyi_bi);
        $info['shouyi'] = $arr[0];
        $info['shouyi_bi'] = $arr[1];
        //每股公积金树状图
        $gongjijin = db("cwbbsjs")->where(['neeq' => $info['neeq'] , 'type' => 3 , 'bbxm' => 'SURPLUSCAPITALPS'])->field("bbrq,xmsz")->order("bbrq asc")->select();
        $gongjijin_bi = [];
        foreach ($gongjijin as $key => $value) {
            if($key == 0){
                array_push($gongjijin_bi, ['bbrq' => $value['bbrq'] , 'xmsz' => 0]);
                $gongjijin[$key]['gongjijin_bi'] = 0;
            } else {
                if(floatval($gongjijin[$key-1]['xmsz'] == 0)){
                    $val = 0;
                } else {
                    $val = (floatval($value['xmsz'])-floatval($gongjijin[$key-1]['xmsz']))/floatval($gongjijin[$key-1]['xmsz']);
                    $val = round(floatval($val), 2);
                }
                array_push($gongjijin_bi, ['bbrq' => $value['bbrq'] , 'xmsz' => $val]);
                $gongjijin[$key]['gongjijin_bi'] = $val;
            }
        }
        $arr = $this->getDataAndBi($gongjijin, $gongjijin_bi);
        $info['gongjijin'] = $arr[0];
        $info['gongjijin_bi'] = $arr[1];
        //每股未分配树状图
        $weifenpei = db("cwbbsjs")->where(['neeq' => $info['neeq'] , 'type' => 3 , 'bbxm' => 'UNDISTRIBUTEDPS'])->field("bbrq,xmsz")->order("bbrq asc")->select();
        $weifenpei_bi = [];
        foreach ($weifenpei as $key => $value) {
            if($key == 0){
                array_push($weifenpei_bi, ['bbrq' => $value['bbrq'] , 'xmsz' => 0]);
                $weifenpei[$key]['weifenpei_bi'] = 0;
            } else {
                if(floatval($weifenpei[$key-1]['xmsz'] == 0)){
                    $val = 0;
                } else {
                    $val = (floatval($value['xmsz'])-floatval($weifenpei[$key-1]['xmsz']))/floatval($weifenpei[$key-1]['xmsz']);
                    $val = round(floatval($val), 2);
                }
                array_push($weifenpei_bi, ['bbrq' => $value['bbrq'] , 'xmsz' => $val]);
                $weifenpei[$key]['weifenpei_bi'] = $val;
            }
        }
        $arr = $this->getDataAndBi($weifenpei, $weifenpei_bi);
        $info['weifenpei'] = $arr[0];
        $info['weifenpei_bi'] = $arr[1];
        //利润表
        $cwbbs1 = db("cwbbs")->where(['neeq' => $info['neeq'] , 'type' => 1])->order("reportdate desc")->select();
        if(!empty($cwbbs1)){
            foreach ($cwbbs1 as $key => $value) {
                if(substr($value['reportdate'], 5, 2) == '12'){
                    $sign = '年';
                } else {
                    $sign = '中';
                }
                $cwbbs1[$key]['reportdate'] = substr($value['reportdate'], 0, 4).$sign.'报';
                $values = [];
                $cwbbs_info = db("cwbbsjs")->where(['neeq' => $info['neeq'] , 'type' => 1 , 'bbrq' => $value['reportdate']])->select();
                foreach ($cwbbs_info as $key1 => $value1) {
                    $xmsz = round(trim($value1['xmsz'], '-'), 2);
                    if($xmsz > 100000000){
                        $zhi = round($value1['xmsz']/100000000 , 2).'亿';
                    }elseif ($xmsz > 10000) {
                        $zhi = round($value1['xmsz']/10000 , 2).'万';
                    } else {
                        $zhi  = round($value1['xmsz'] , 2).'元';
                    }
                    $values[$value1['bbxm']] = $zhi;
                }
                $cwbbs1[$key]['value'] = $values;
            }
        }
        $info['cwbbs1'] = $cwbbs1;
        //资产负债表
        $cwbbs2 = db("cwbbs")->where(['neeq' => $info['neeq'] , 'type' => 0])->order("reportdate desc")->select();
        if(!empty($cwbbs2)){
            foreach ($cwbbs2 as $key => $value) {
                if(substr($value['reportdate'], 5, 2) == '12'){
                    $sign = '年';
                } else {
                    $sign = '中';
                }
                $cwbbs2[$key]['reportdate'] = substr($value['reportdate'], 0, 4).$sign.'报';
                $values = [];
                $cwbbs_info = db("cwbbsjs")->where(['neeq' => $info['neeq'] , 'type' => 0 , 'bbrq' => $value['reportdate']])->select();
                foreach ($cwbbs_info as $key1 => $value1) {
                    $xmsz = round(trim($value1['xmsz'], '-'), 2);
                    if($xmsz > 100000000){
                        $zhi = round($value1['xmsz']/100000000 , 2).'亿';
                    }elseif ($xmsz > 10000) {
                        $zhi = round($value1['xmsz']/10000 , 2).'万';
                    } else {
                        $zhi  = round($value1['xmsz'] , 2).'元';
                    }
                    $values[$value1['bbxm']] = $zhi;
                }
                $cwbbs2[$key]['value'] = $values;
            }
        }
        $info['cwbbs2'] = $cwbbs2;
        //现金流量表
        $cwbbs3 = db("cwbbs")->where(['neeq' => $info['neeq'] , 'type' => 2])->order("reportdate desc")->select();
        if(!empty($cwbbs3)){
            foreach ($cwbbs3 as $key => $value) {
                if(substr($value['reportdate'], 5, 2) == '12'){
                    $sign = '年';
                } else {
                    $sign = '中';
                }
                $cwbbs3[$key]['reportdate'] = substr($value['reportdate'], 0, 4).$sign.'报';
                $values = [];
                $cwbbs_info = db("cwbbsjs")->where(['neeq' => $info['neeq'] , 'type' => 2 , 'bbrq' => $value['reportdate']])->select();
                foreach ($cwbbs_info as $key1 => $value1) {
                    $xmsz = round(trim($value1['xmsz'], '-'), 2);
                    if($xmsz > 100000000){
                        $zhi = round($value1['xmsz']/100000000 , 2).'亿';
                    }elseif ($xmsz > 10000) {
                        $zhi = round($value1['xmsz']/10000 , 2).'万';
                    } else {
                        $zhi  = round($value1['xmsz'] , 2).'元';
                    }
                    $values[$value1['bbxm']] = $zhi;
                }
                $cwbbs3[$key]['value'] = $values;
            }
        }
        $info['cwbbs3'] = $cwbbs3;
        return $info;
    }
	public function getDataAndBi($arr , $arr1){
        $a = [];$b = [];
        if(count($arr) <= count($arr1)){
            foreach ($arr as $key => $value) {
                foreach ($arr1 as $key1 => $value1) {
                    if($value['bbrq'] == $value1['bbrq']){
                        array_push($a, $value);
                        array_push($b, $value1);
                    }
                }
            }
        } else {
            foreach ($arr1 as $key1 => $value1) {
                foreach ($arr as $key => $value) {
                    if($value['bbrq'] == $value1['bbrq']){
                        array_push($a, $value);
                        array_push($b, $value1);
                    }
                }
            }
        }
        return [$a , $b];
    }
	
}