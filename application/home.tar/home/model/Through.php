<?php

namespace app\home\model;

use think\Model;

class Through extends Model
{
    public function getThroughInfoById($id){
        if(empty($id)){
            $this->error = '用户id不存在';
            return false;
        }
        $result = $this->where(['uid' => $id])->find();
        return $result;
    }

    public function createThrough($data){
        if(empty($data)){
            $this->error = '认证数据不存在';
            return false;
        }
        $user = session('FINANCE_USER');
        $uid = $user['uid'];
        $info = $this->where(['uid' => $uid])->find();
        //验证数据信息
        $validate = validate('Through');
        $scene = empty($info) ? 'add' : 'edit';
        if(!$validate->scene($scene)->check($data)){
            $error = $validate->getError();
            $this->error = $error;
            return false;
        }

        //开启事务
        $this->startTrans();
        try{
            if(!empty($info)){
                model("Member")->where(['uid' => $uid])->update(['realName' => $data['realname']]);
                $arr = [];
                $arr['realName'] = $data['realname'];
                //$arr['email'] = $data['email'];
                //$arr['company'] = $data['company'];
                //$arr['position'] = $data['position'];
                $arr['card'] = $data['card'];
                if(isset($data['phone'])){
                    $arr['phone'] = $data['phone'];
                    model("Member")->where(['uid' => $uid])->update(['userPhone' => $data['phone'] ,'userType' => 1]);
                }
                $arr['updateTime'] = time();
                $arr['status'] = 0;
                $this->where(['uid' => $uid])->update($arr);
            } else {
                model("Member")->where(['uid' => $uid])->update(['realName' => $data['realname']]);
                $arr = [];
                $arr['uid'] = $uid;
                $arr['realName'] = $data['realname'];
                //$arr['email'] = $data['email'];
                //$arr['company'] = $data['company'];
                //$arr['position'] = $data['position'];
                $arr['card'] = $data['card'];
                if(isset($data['phone'])){
                    $arr['phone'] = $data['phone'];
                    model("Member")->where(['uid' => $uid])->update(['userPhone' => $data['phone'] ,'userType' => 1]);
                }
                $arr['createTime'] = time();
                $arr['updateTime'] = time();
                $arr['throughTime'] = 0;
                $arr['lastTime'] = 0;
                $arr['status'] = 0;
                $this->allowField(true)->save($arr);
            }
            // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
}