<?php

namespace app\home\model;

use think\Model;

class MaterialLibrary extends Model
{
    public function getMaterialInfoById($id){
        $result = $this->where(['ml_id' => $id])->find();
        return $result;
    }
}