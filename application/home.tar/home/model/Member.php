<?php

namespace app\home\model;

use think\Model;

class Member extends Model
{
    public function setCollectionStudy($data){
        if(empty($data)){
            $this->error = '缺少文章数据';
            return false;
        }
        //开启事务
        $this->startTrans();
        try{
            $arr = [];
            $model = model("Member");
            $user = $model->where(['openId' => $data['openid']])->find();
            $collection_study = explode(',', $user['collection_study']);
            if(!in_array($data['id'], $collection_study)){
                array_push($collection_study, $data['id']);
                $coll = trim(implode(',', $collection_study), ',');
                $model->where(['openId' => $data['openid']])->update(['collection_study' => $coll]);
            }
            // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
    public function getMemberInfoById($id){
        $result = $this->where(['uid' => $id])->find();
        return $result;
    }
    public function setMemberProSearch($text){
        $uid = session('FINANCE_USER.uid');
        $result = true;
        $info = $this->where(['uid' => $uid])->find();
        $arr = explode(',', $info['pro_search']);
        $search = array_slice($arr, 0, 10);
        if(!in_array($text, $arr)){
            array_push($search, $text);
            $search = array_slice($search, 0, 10);
            $str = trim(implode(',', $search), ',');
            session('FINANCE_USER.pro_search' , $str);
            $result = $this->where(['uid' => $uid])->update(['pro_search' => $str]);
        }
        return $result;
    }

    /**
	 * 用户登录验证
	 */
	public function checkLogin($wxUser){
		$where = array();
		$where['openId'] = $wxUser['openid'];
        $user = $this->where($where)->find();
		//如果存在，则进行登录，如果不存在，则进行注册
		if(!empty($user) && $user['openId']==$wxUser['openid']){
			if($user['status']==1){
				$data = array();
				$data['userName']  = $wxUser['nickname'];
				$data['lastTime']  = time();
				$data['lastIP'] = get_client_ip();
				$data['userPhoto'] = $wxUser['headimgurl'];
		    	$this->where(['uid' => $user['uid']])->update($data);
			} else {
                //账号不能用,此情况暂时没有
            }
		}else {
            $data = array();
			$data['userType'] = 0;
            if($wxUser['superior'] != null){
                $info = $this->getMemberInfoById($wxUser['superior']);
                if($info['userType'] == 2){
                    $data['superior'] = $wxUser['superior'];
                    $arr = [];
                    $arr['uid'] = $wxUser['superior'];
                    $arr['integral'] = config("integral");
                    $arr['reason'] = '分享链接，带来注册用户：'.$wxUser['nickname'];
                    $arr['create_time'] = time();
                    $arr['openId'] = $wxUser['openid'];
                    model("IntegralRecord")->allowField(true)->save($arr);
                } else {
                    $data['superior'] = 0;
                }
            } else {
                $data['superior'] = 0;
            }
			$data['userName'] = $wxUser['nickname'];
			$data['userSex'] = $wxUser['sex']==0 ? 3 : $wxUser['sex']==1 ? 1 : 2;
			$data['userPhone'] = '';
			$data['createTime'] = time();
			$data['CREATE_TIME'] = date('Y-m-d H:i:s' , time());
			$data['userPhoto'] = $wxUser['headimgurl'];
			$data['lastTime'] = time();
			$data['lastIP'] = get_client_ip();
			$data['openId'] = $wxUser['openid'];
            $data['status'] = 1;
			$result = $this->allowField(true)->save($data);
            $model = model("IntegralRecord");
		}
        $user = $this->where($where)->find();
		return $user;
	}
}