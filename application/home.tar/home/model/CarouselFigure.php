<?php

namespace app\home\model;

use think\Model;

class CarouselFigure extends Model
{
    public function getCarouselFigureList(){
        $result = $this->where(['status' => 1])->order("list_order desc")->select();
        $model = model("MaterialLibrary");
        foreach ($result as $key => $value) {
            $img = $model->getMaterialInfoById($value['img']);
            $result[$key]['img_url'] = $img['url'];
        }
        return $result;
    }
}