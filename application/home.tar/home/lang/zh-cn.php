<?php
return [
    'system_manage'  => '系统管理',

    //系统权限
    'do_not_have_privilege' => '您没有操作此项的权限！',
    'get_no_user_please_relogin' => '用户信息获取失败，请重新登录！',
    'account_locked' => '您的帐号已经被锁定！'
];