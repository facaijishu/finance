<?php
return [
    'system_manage'  => 'System Management',
];
