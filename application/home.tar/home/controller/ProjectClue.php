<?php
namespace app\home\controller;

class ProjectClue extends Base
{
    public function index(){
        $this->assign('title' , '项目线索 -');
        $this->assign('img' , '');
        $this->assign('des' , '这里可以提交您的项目!');
        return view();
    }
    public function add(){
        if(request()->isPost()){
            $projectclue = model('ProjectClue');
            if($projectclue->createProjectClue(input())){
                $url = url('ProjectClue/succeed');
                header("Location: $url");
                die;
            }else{
                $error = $projectclue->getError() ? $projectclue->getError() : '添加项目失败';
                $url = url('ProjectClue/lose' , ['error' => $error]);
                header("Location: $url");
                die;
            }
        } else {
            $model = model("dict");
            $list = $model->getDictByType("capital_plan");
            $this->assign('list' , $list);
            $this->assign('title' , '项目线索 -');
            $this->assign('img' , '');
            $this->assign('des' , '这里可以提交您的项目!');
            return view();
        }
    }
    public function upload(){
        $file = $_FILES;
        if($file){
            $name = explode('.', $file['file']['name']);
            $type = $name[count($name)-1];
            $filename = date('ymd').rand(1000, 9999).'.'.$type;
            if(in_array($type, ['jpg' , 'jpeg' , 'gif' , 'png'])){
                $path = ROOT_PATH . 'public' . DS . 'uploads' . DS . 'home' . DS . 'project_clue' . DS;
                if(!is_dir($path)){
                    mkdir($path , 0777 , true);
                }
                $result = move_uploaded_file($file['file']['tmp_name'], $path.$filename);
                if($result){
                    $data['name'] = $filename;
                    $this->result($data ,1 , '上传成功' , 'json');
                }else{
                    $this->result('', 0, '上传失败', 'json');
                }
            } else {
                $this->result('' ,0 , '上传文件格式不正确' , 'json');
            }
        } else {
            $this->result('' ,0 , '图片不存在' , 'json');
        }
    }
    public function succeed(){
        $this->assign('title' , '项目线索 -');
        $this->assign('img' , '');
        $this->assign('des' , '这里可以提交您的项目!');
        return view();
    }
    public function lose(){
        $error = $this->request->param('error/s');
        $this->assign('error' , $error);
        $this->assign('title' , '项目线索 -');
        $this->assign('img' , '');
        $this->assign('des' , '这里可以提交您的项目!');
        return view();
    }
}