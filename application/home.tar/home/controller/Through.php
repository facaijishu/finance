<?php

namespace app\home\controller;

class Through extends Base{
    public function index(){
        $info = $this->jsGlobal;
        $this->assign('info' , $info);
        $this->assign('title' , '认证中心 -');
        $this->assign('img' , '');
        $this->assign('des' , '这里有最严谨的认证过程!');
        return view();
    }
    //名片上传
    public function upload(){
        $file = $_FILES;
        if($file){
            $name = explode('.', $file['cardup']['name']);
            $type = $name[count($name)-1];
            $filename = date('ymd').rand(1000, 9999).'.'.$type;
            if(in_array(strtolower($type), ['jpg' , 'jpeg' , 'gif' , 'png'])){
                $path = ROOT_PATH . 'public' . DS . 'uploads' . DS . 'home' . DS . 'card' . DS;
                if(!is_dir($path)){
                    mkdir($path , 0777 , true);
                }
                $result = move_uploaded_file($file['cardup']['tmp_name'], $path.$filename);
                if($result){
                    $data['name'] = $filename;
                    $this->result($data ,1 , '上传成功' , 'json');
                }else{
                    $this->result('', 0, '上传失败', 'json');
                }
            } else {
                $this->result('' ,0 , '上传文件格式不正确' , 'json');
            }
        } else {
            $this->result('' ,0 , '图片不存在' , 'json');
        }
    }
    //添加认证
    public function add(){
        $data = input();
        if(isset($data['code'])){
            if($data['code'] == session('code')){
                session('code', null);
                $model = model("through");
                if($model->createThrough($data)){
                    $model1 = model("Member");
                    $user = session('FINANCE_USER');
                    $info = $model1->where(['uid' => $user['uid']])->find();
                    if ($info['customerService'] != 0) {
                        $result = model('SelfCustomerService')->getCustomerServiceById($info['customerService']);
                    }else {
                        $result = model('SelfCustomerService')->getRandomCustomerService($user['uid']);
                    }
                    if(!empty($info['lastTime'])){
                        $info['lastTime'] = date('Y-m-d H:i:s',$info['lastTime']);
                    }
                    $result_m = model('Binding')->sendProjectInfo($result['real_name'],$info['userPhone'],$info['lastTime'],"绑定用户",$result['kf_openId'],$user['uid']);
                    if(!$result_m){
                        $data = [];
                        $this->result($data, 1, '发送消息模板失败', 'json');
                    }
                    session('FINANCE_USER' , $info);
                    $data = [];
                    $data['url'] = url('Through/succeed');
                    $this->result($data, 1, '添加认证信息成功', 'json');
                }else{
                    $error = $model->getError() ? $model->getError() : '添加认证失败';
                    $this->result('', 0, $error, 'json');
                }
            } else {
                $this->result('', 0, '验证码不正确', 'json');
            }
        } else {
            $model = model("through");
            if($model->createThrough($data)){
                $model = model("Member");
                $user = session('FINANCE_USER');
                $info = $model->where(['uid' => $user['uid']])->find();

                session('FINANCE_USER' , $info);
                session('code',null);
                $data = [];
                $data['url'] = url('Through/succeed');
                $this->result($data, 1, '添加认证信息成功', 'json');
            }else{
                $error = $model->getError() ? $model->getError() : '添加认证失败';
                $this->result('', 0, $error, 'json');
            }
        }
    }
    //添加认证成功
    public function succeed(){
        $this->assign('title' , '认证中心 -');
        $this->assign('img' , '');
        $this->assign('des' , '这里有最严谨的认证过程!');
        return view();
    }
    //获取手机验证码
    public function getNumber(){
        $mobile = $this->request->param('phone/s');
		$id = $this->request->param("id");
        $partten = '/^(0|86|17951)?(13[0-9]|15[012356789]|17[0-9]|18[0-9]|14[57])[0-9]{8}$/';
        if(empty($mobile) || preg_match($partten, $mobile) == 0){
            $this->result('', -1, '手机号码不正确', 'json');
        }
		//判断该手机号是否已经注册过
		if(!empty($id)){
			$sult = model("through")->where("phone = ".$mobile." and status = 1")->find();
			if(!empty($sult)){
				$t = [];
				$this->result($t, 1, "该手机号已经注册过", 'json');
			}
		}
		
        $apikey = "b4d4e18d335a960c008deca958c37326"; 
        $number = rand(100000, 999999);
        session('code', $number);
//        $this->number = $number;
        $text="【FA財】您的验证码是".$number;
//        $ch = curl_init();
//        // 设置验证方式
//        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept:text/plain;charset=utf-8', 'Content-Type:application/x-www-form-urlencoded','charset=utf-8'));
//        // 设置返回结果为流
//        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//        // 设置超时时间
//        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
//        // 设置通信方式
//        curl_setopt($ch, CURLOPT_POST, 1);
//        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
//        $data=array('text'=>$text,'apikey'=>$apikey,'mobile'=>$mobile);
//        $json_data = $this->send($ch,$data);
        vendor("Passport.Sms");
        $sms = new \Sms('ac67816e0f384393545628fc31dc3b17');
        $array = $sms->send($mobile, $text, null);
// 		$res = $SMS->send($order['userPhone'], $sms, null);	
        
//        $array = json_decode($json_data,true);
//        curl_close($ch);
        $array = json_decode(json_encode($array) , true);
//        $array = (array)$array;
        if($array['code'] == 0){
//            $array['data'] = (array)$array['data'];
//            $array['data'][0] = (array)$array['data'][0];
            if($array['data'][0]['sendState'] == 'SUCCESS'){
                $this->result($array, 0, '发送成功', 'json');
            } else {
                $this->result($array, 1, $array['data'][0]['reason'], 'json');
            }
        } else {
            $this->result($array, 1, $array['msg'], 'json');
        }
    }
//    function send($ch,$data){
//        curl_setopt ($ch, CURLOPT_URL, 'https://sms.yunpian.com/v2/sms/single_send.json');
//        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
//        $result = curl_exec($ch);
//        $error = curl_error($ch);
//        if(empty($error)){
//            $result = $result;
//        } else {
//            $result = $error;
//        }
//        return $result;
//    }
}