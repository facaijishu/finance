<?php
namespace app\console\controller;

class Project extends ConsoleBase{
    public function index(){
//        $info = model('Project')->where(['pro_id' => 27])->find();
//        $array = [
//                'first' => ['value' => '您好，您有一个新项目上线!' , 'color' => '#173177'],
//                'keyword1' => ['value' => $info['contacts'].'【手机:'.$info['contacts_tel'].'】【邮箱:'.$info['contacts_email'].'】' , 'color' => '#0D0D0D'],
//                'keyword2' => ['value' => $info['pro_name'] , 'color' => '#0D0D0D'],
//                'keyword3' => ['value' => $info['introduction'] , 'color' => '#0D0D0D'],
//                'keyword4' => ['value' => $info['inc_industry'] , 'color' => '#0D0D0D'],
//                'keyword5' => ['value' => $info['need'] , 'color' => '#0D0D0D'],
//                'remark' => ['value' => '请点击详情查看!' , 'color' => '#173177'],
//            ];
//        $model = model('Send');
//        $send_id = $model->addSendInfo(['content' => json_encode($array), 'type' => 'project', 'act_id' => 27]);
//        $end = sendTemplateMessage(config("new_project"), 'osmRL1oNHPT0NeZqh4TjTFV2cONw', $_SERVER['SERVER_NAME'].'/home/project_info/index/id/'.$info['pro_id'], $array);
//        $end = getSendCodeMsg($end);
//        $result = explode('-', $end);
//        $result = $result[0] == 0 ? 'true' : 'false';
//        $ars = ['userName' => '见这个行号', 'openId' => 'osmRL1oNHPT0NeZqh4TjTFV2cONw', 'send_id' => $send_id, 'content' => $end, 'result' => $result];
//        $aa = model('SendList')->addSendListInfo($ars);
//        var_dump($send_id);
//        var_dump($aa);
//        $list = model("Project")->order("pro_id asc")->select();
//        $list1 = model("ZfmxesAdd")->order("id asc")->select();
//        $list2 = model("ZryxesEffect")->order("id asc")->select();
//        $str = '';$str1 = '';$str2 = '';
//        $i = 1;
//        foreach ($list as $key => $value) {
//            $info = model("Project")->where(['pro_id' => $value['pro_id']])->update(['qr_code' => $i]);
////            $str .= "insert into `fic_qrcode_direction` values (".$i.",'project',".$value['pro_id'].",'','','".$value['qr_code']."');";
//            $i++;
//        }
//        $length = count($list);
//        var_dump($length);
//        foreach ($list1 as $key => $value) {
//            $info = model("ZfmxesAdd")->where(['id' => $value['id']])->update(['qr_code' => $i]);
////            $str1 .= "insert into `fic_qrcode_direction` values (".$i.",'zfmxes','','".$value['neeq']."','".$value['plannoticeddate']."','".$value['qr_code']."');";
//            $i++;
//        }
//        $length = count($list)+count($list1);
//        var_dump($length);
//        foreach ($list2 as $key => $value) {
//            $info = model("ZryxesEffect")->where(['id' => $value['id']])->update(['qr_code' => $i]);
////            $str2 .= "insert into `fic_qrcode_direction` values (".$i.",'zryxes',".$value['id'].",'','','".$value['qr_code']."');";
//            $i++;
//        }
////        var_dump($str);
////        var_dump($str1);
//        var_dump($str2);
        return view();
    }
    public function read(){
        $return = [];
        $order = $this->request->get('order/a', []);
        $start = $this->request->get('start', 0);
        $length = $this->request->get('length', config('paginate.list_rows'));

        $create_date1 = $this->request->get('create_date1', '');
        $create_date2 = $this->request->get('create_date2', '');
        $status = $this->request->get('status', '');
        $pro_name = $this->request->get('pro_name', '');

        $project = model('Project')
                ->alias("p")
                ->join("QrcodeDirection qd","p.qr_code=qd.id","LEFT")
                ->field("SQL_CALC_FOUND_ROWS p.*,qd.qrcode_path");
        //搜索条件
        if('' !== $create_date1 && '' !== $create_date2) {
            $project->where('create_time','between',[strtotime($create_date1.'00:00:00') , strtotime($create_date2.'23:59:59')]);
        }elseif ('' !== $create_date1 && '' == $create_date2) {
            $project->where('create_time','>',strtotime($create_date1.'00:00:00'));
        }elseif ('' == $create_date1 && '' !== $create_date2) {
            $project->where('create_time','<',strtotime($create_date2.'23:59:59'));
        }
        if('' !== $status) {
            $project->where(['status'=>$status]);
        }
        if('' !== $pro_name) {
            $project->where('pro_name','like','%'.$pro_name.'%');
        }
        //排序
        if(!empty($order)) {
            foreach ($order as $item) {
                $_order = [];
                $_order[$item['column']] = $item['dir'];
            }
            $project->order($_order);
        }
//        $project->field('SQL_CALC_FOUND_ROWS *');
        $list = $project->limit($start, $length)->select();
        $result = $project->query('SELECT FOUND_ROWS() as count');
        $total = $result[0]['count'];
        $data = [];
        foreach ($list as $key => $item) {
            $list[$key]['last_time'] = date('Y-m-d H:i:s', $item['last_time']);
            $data[] = $item->toArray();
        }
        $return['data'] = $data;
        $return['recordsFiltered'] = $total;
        $return['recordsTotal'] = $total;

        echo json_encode($return);
    }
    public function add(){
        if(request()->isPost()){
            $project = model('Project');
            if($project->createProject(input())){
                $data['url'] = url('Project/index');
                $this->result($data, 1, '添加项目成功', 'json');
            }else{
                $error = $project->getError() ? $project->getError() : '添加项目失败';
                $this->result('', 0, $error, 'json');
            }
        }else{
            $model = model("dict");
            $inc_industry = $model->getDictByType('industry');
            $this->assign('inc_industry' , $inc_industry);
            $inc_area = $model->getDictByType('section');
            $this->assign('inc_area' , $inc_area);
            $capital_plan = $model->getDictByType('capital_plan');
            $this->assign('capital_plan' , $capital_plan);
            $transfer_type = $model->getDictByType("transfer_type");
            $this->assign('transfer_type' , $transfer_type);
            $hierarchy = $model->getDictByType("hierarchy");
            $this->assign('hierarchy' , $hierarchy);
            $sign = $model->getDictByType("sign");
            $this->assign('sign' , $sign);
            return view();
        }
    }
    public function edit(){
        if(request()->isPost()){
            $project = model('Project');
            if($project->createProject(input())){
                $data['url'] = url('Project/index');
                $this->result($data, 1, '修改项目成功', 'json');
            }else{
                $error = $project->getError() ? $project->getError() : '修改项目失败';
                $this->result('', 0, $error, 'json');
            }
        }else{
            $id = $this->request->param('pro_id/d');
            $model = model("project");
            $info = $model->getProjectInfoById($id);
            $info['industry'] = explode(',', $info['inc_industry']);
            $info['area'] = explode(',', $info['inc_area']);
            $info['sign'] = explode(',', $info['inc_sign']);
            $info['build_time'] = date('Y-m-d' , $info['build_time']);
            
            $model = model("material_library");
            $top_img = $model->getMaterialInfoById($info['top_img']);
            $info['top_img_url'] = $top_img['name'];
            $business_plan = $model->getMaterialInfoById($info['business_plan']);
            $info['business_plan_url'] = $business_plan['name'];
            $factor_table = $model->getMaterialInfoById($info['factor_table']);
            $info['factor_table_url'] = $factor_table['name'];
            $company_video = $model->getMaterialInfoById($info['company_video']);
            $info['company_video_url'] = $company_video['name'];
            
            $model = model("material_library");
            
            $str = '';$url = [];$config = [];$arr = [];
            if($info['enterprise_url'] != ''){
                $enterprise_url = explode(',', $info['enterprise_url']);
                foreach ($enterprise_url as $key => $value) {
                    $material = $model->getMaterialInfoById($value);
                    array_push($arr, $material['url']);
                    $str .= $material['ml_id'].'-init_'.$key.',';
                    array_push($url, 'http://' . $_SERVER['SERVER_NAME'] . DS . 'uploads' . DS . $material['url']);
                    $config[$key]['caption'] = $material['name'];
                    $config[$key]['size'] = $material['filesize'];
                    $config[$key]['key'] = $key;
                    $config[$key]['url'] = url("Project/deleteImg");
                }
                $info['enterprise_url'] = $str;
                
            }
            $info['enterprise_url_arr'] = $arr;
            $this->assign('enterprise_url_url' , json_encode($url));
            $this->assign('enterprise_url_config' , json_encode($config));
            $str = '';$url = [];$config = [];$arr = [];
            if($info['company_url'] != ''){
                $company_url = explode(',', $info['company_url']);
                foreach ($company_url as $key => $value) {
                    $material = $model->getMaterialInfoById($value);
                    array_push($arr, $material['url']);
                    $str .= $material['ml_id'].'-init_'.$key.',';
                    array_push($url, 'http://' . $_SERVER['SERVER_NAME'] . DS . 'uploads' . DS . $material['url']);
                    $config[$key]['caption'] = $material['name'];
                    $config[$key]['size'] = $material['filesize'];
                    $config[$key]['key'] = $key;
                    $config[$key]['url'] = url("Project/deleteImg");
                }
                $info['company_url'] = $str;
                
            }
            $info['company_url_arr'] = $arr;
            $this->assign('company_url_url' , json_encode($url));
            $this->assign('company_url_config' , json_encode($config));
            $str = '';$url = [];$config = [];$arr = [];
            if($info['product_url'] != ''){
                $product_url = explode(',', $info['product_url']);
                foreach ($product_url as $key => $value) {
                    $material = $model->getMaterialInfoById($value);
                    array_push($arr, $material['url']);
                    $str .= $material['ml_id'].'-init_'.$key.',';
                    array_push($url, 'http://' . $_SERVER['SERVER_NAME'] . DS . 'uploads' . DS . $material['url']);
                    $config[$key]['caption'] = $material['name'];
                    $config[$key]['size'] = $material['filesize'];
                    $config[$key]['key'] = $key;
                    $config[$key]['url'] = url("Project/deleteImg");
                }
                $info['product_url'] = $str;
                
            }
            $info['product_url_arr'] = $arr;
            $this->assign('product_url_url' , json_encode($url));
            $this->assign('product_url_config' , json_encode($config));
            $str = '';$url = [];$config = [];$arr = [];
            if($info['analysis_url'] != ''){
                $analysis_url = explode(',', $info['analysis_url']);
                foreach ($analysis_url as $key => $value) {
                    $material = $model->getMaterialInfoById($value);
                    array_push($arr, $material['url']);
                    $str .= $material['ml_id'].'-init_'.$key.',';
                    array_push($url, 'http://' . $_SERVER['SERVER_NAME'] . DS . 'uploads' . DS . $material['url']);
                    $config[$key]['caption'] = $material['name'];
                    $config[$key]['size'] = $material['filesize'];
                    $config[$key]['key'] = $key;
                    $config[$key]['url'] = url("Project/deleteImg");
                }
                $info['analysis_url'] = $str;
                
            }
            $info['analysis_url_arr'] = $arr;
            $this->assign('analysis_url_url' , json_encode($url));
            $this->assign('analysis_url_config' , json_encode($config));
            
            $this->assign('info' , $info);
            $model = model("dict");
            $inc_industry = $model->getDictByType('industry');
            $this->assign('inc_industry' , $inc_industry);
            $inc_area = $model->getDictByType('section');
            $this->assign('inc_area' , $inc_area);
            $capital_plan = $model->getDictByType('capital_plan');
            $this->assign('capital_plan' , $capital_plan);
            $transfer_type = $model->getDictByType("transfer_type");
            $this->assign('transfer_type' , $transfer_type);
            $hierarchy = $model->getDictByType("hierarchy");
            $this->assign('hierarchy' , $hierarchy);
            $inc_sign = $model->getDictByType("sign");
            $this->assign('inc_sign' , $inc_sign);
            return view();
        }
    }
    public function detail(){
        $id = $this->request->param('id/d');
        $model = model("project");
        $info = $model->getProjectInfoById($id);
        $model = model("dict");
        $industry = explode(',', $info['inc_industry']);
        $inc_industry = '';
        foreach ($industry as $key => $value) {
            $dict = $model->getDictInfoById($value);
            $inc_industry .= $dict['value'].' , ';
        }
        $info['inc_industry'] = trim($inc_industry , ' , ');
        $area = explode(',', $info['inc_area']);
        $inc_area = '';
        foreach ($area as $key => $value) {
            $dict = $model->getDictInfoById($value);
            $inc_area .= $dict['value'].' , ';
        }
        $info['inc_area'] = trim($inc_area , ' , ');
        $sign = explode(',', $info['inc_sign']);
        $inc_sign = '';
        foreach ($sign as $key => $value) {
            $dict = $model->getDictInfoById($value);
            $inc_sign .= $dict['value'].' , ';
        }
        $info['inc_sign'] = trim($inc_sign , ' , ');
        $capital_plan = $model->getDictInfoById($info['capital_plan']);
        $info['capital_plan'] = $capital_plan['value'];
        $info['build_time'] = date('Y-m-d' , $info['build_time']);
        $transfer_type = $model->getDictInfoById($info['transfer_type']);
        $info['transfer_type'] = $transfer_type['value'];
        $hierarchy = $model->getDictInfoById($info['hierarchy']);
        $info['hierarchy'] = $hierarchy['value'];
        $info['investment_lights'] = $this->getTextAreaValue($info['investment_lights']);
        $info['enterprise_des'] = $this->getTextAreaValue($info['enterprise_des']);
        $info['company_des'] = $this->getTextAreaValue($info['company_des']);
        $info['product_des'] = $this->getTextAreaValue($info['product_des']);
        $info['analysis_des'] = $this->getTextAreaValue($info['analysis_des']);
        
        $model = model("material_library");
        $top_img = $model->getMaterialInfoById($info['top_img']);
        $info['top_img'] = $top_img['name'];
        $business_plan = $model->getMaterialInfoById($info['business_plan']);
        $info['business_plan'] = $business_plan['name'];
        $factor_table = $model->getMaterialInfoById($info['factor_table']);
        $info['factor_table'] = $factor_table['name'];
        $company_video = $model->getMaterialInfoById($info['company_video']);
        $info['company_video'] = $company_video['name'];
        
        $arr = [];
        if($info['enterprise_url'] != ''){
            $enterprise_url = explode(',', $info['enterprise_url']);
            foreach ($enterprise_url as $key => $value) {
                $material = $model->getMaterialInfoById($value);
                array_push($arr, $material['url']);
            }
        }
        $info['enterprise_url_arr'] = $arr;
        $arr = [];
        if($info['company_url'] != ''){
            $company_url = explode(',', $info['company_url']);
            foreach ($company_url as $key => $value) {
                $material = $model->getMaterialInfoById($value);
                array_push($arr, $material['url']);
            }
        }
        $info['company_url_arr'] = $arr;
        $arr = [];
        if($info['product_url'] != ''){
            $product_url = explode(',', $info['product_url']);
            foreach ($product_url as $key => $value) {
                $material = $model->getMaterialInfoById($value);
                array_push($arr, $material['url']);
            }
        }
        $info['product_url_arr'] = $arr;
        $arr = [];
        if($info['analysis_url'] != ''){
            $analysis_url = explode(',', $info['analysis_url']);
            foreach ($analysis_url as $key => $value) {
                $material = $model->getMaterialInfoById($value);
                array_push($arr, $material['url']);
            }
        }
        $info['analysis_url_arr'] = $arr;
            
        $this->assign('info' , $info);
        $model = model("dict");
        $qa_type = $model->getDictByType("qa_type");
        $this->assign('qa_type' , $qa_type);
        //问答分页
        $model = model("project_qa");
        $qa_list = $model->getProjectListByProId($id , 0 , 5);
        $count = $model->getProjectListByProId($id);
        foreach ($qa_list as $key => $value) {
            $type = model("dict")->getDictInfoById($value['type']);
            $qa_list[$key]['type'] = $type['value'];
        }
        $this->assign('qa_list' , $qa_list);
        $num = intval(count($count)/5);
        if(count($count)%5 > 0){
            $total = $num++;
        } else {
            $total = $num;
        }
        $this->assign('total1' , $num);
        //新闻分页
        $model = model("project_news");
        $news_list = $model->getProjectListByProId($id , 0 , 5);
        $count = $model->getProjectListByProId($id);
        $this->assign('news_list' , $news_list);
        $num = intval(count($count)/5);
        if(count($count)%5 > 0){
            $total = $num++;
        } else {
            $total = $num;
        }
        $this->assign('total2' , $num);
        return view();
    }
    
    public function save(){
        $data = input();
        $con = model('project');
        if(isset($data['pro_id'])){
            if ($con->createProjectDraft(input())) {
                $data['url'] = url('Project/index');
                $this->result($data, 1, '修改项目成功', 'json');
            } else {
                $error = $con->getError() ? $con->getError() : '修改项目失败';
                $this->result('', 0, $error, 'json');
            }
        } else {
            if ($con->createProjectDraft(input())) {
                $data['url'] = url('Project/index');
                $this->result($data, 1, '添加项目成功', 'json');
            } else {
                $error = $con->getError() ? $con->getError() : '添加项目失败';
                $this->result('', 0, $error, 'json');
            }
        }
    }
    public function end(){
        $id = $this->request->param('id/d');
        $model = model("project");
        if($model->setProjectStatus($id , 3)){
            $data['url'] = url('Project/index');
            $this->result($data, 1, '设置成功', 'json');
        }else{
            $error = $model->getError() ? $model->getError() : '设置失败';
            $this->result('', 0, $error, 'json');
        }
    }
    public function stop(){
        $id = $this->request->param('id/d');
        $model = model("project");
        if($model->stopProject($id)){
            $data['url'] = url('Project/index');
            $this->result($data, 1, '隐藏成功', 'json');
        }else{
            $error = $model->getError() ? $model->getError() : '隐藏失败';
            $this->result('', 0, $error, 'json');
        }
    }
    public function start(){
        $id = $this->request->param('id/d');
        $model = model("project");
        if($model->startProject($id)){
            $data['url'] = url('Project/index');
            $this->result($data, 1, '显示成功', 'json');
        }else{
            $error = $model->getError() ? $model->getError() : '显示失败';
            $this->result('', 0, $error, 'json');
        }
    }
    public function deleteImg(){
        $data = input();
        $this->result($data['key'], 1, '删除成功！', 'json');
    }
    public function sendinfo(){
        $id = $this->request->param('id/d');
        $model = model("project");
        if($model->sendProjectInfo($id)){
            $data['url'] = url('Project/index');
            $this->result($data, 1, '推送成功', 'json');
        }else{
            $error = $model->getError() ? $model->getError() : '推送失败';
            $this->result('', 0, $error, 'json');
        }
    }
}