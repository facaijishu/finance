<?php
namespace app\console\controller;

class Dict extends ConsoleBase{
    public function index(){
        $model = model("dict_type");
        $dict_type_list = $model->getDictTypeList();
        $this->assign('dict_type_list' , $dict_type_list);
        return view();
    }
    public function read(){
        $return = [];
        $order = $this->request->get('order/a', []);
        $start = $this->request->get('start', 0);
        $length = $this->request->get('length', config('paginate.list_rows'));

        $name = $this->request->get('name', '');
        $type = $this->request->get('type', '');

        $dict = model('dict');
        //搜索条件
        if('' !== $name) {
            $dict->where('value','like','%'.$name.'%');
        }
        if('' !== $type) {
            $dict->where('dt_id','eq',$type);
        }
        //排序
        if(!empty($order)) {
            foreach ($order as $item) {
                $_order = [];
                $_order[$item['column']] = $item['dir'];
            }
            $dict->order($_order);
        }
        $dict->field('SQL_CALC_FOUND_ROWS *');
        $list = $dict->limit($start, $length)->select();
        $result = $dict->query('SELECT FOUND_ROWS() as count');
        $total = $result[0]['count'];
        $data = [];
        $model = model("dict_type");
        $user = model("user");
        foreach ($list as $key => $item) {
            $type_info = $model->getDictTypeInfoById($item['dt_id']);
            $user_info = $user->getUserById($item['create_uid']);
            $list[$key]['dt_id'] = $type_info['name'];
            $list[$key]['create_uid'] = $user_info['real_name'];
            $data[] = $item->toArray();
        }
        $return['data'] = $data;
        $return['recordsFiltered'] = $total;
        $return['recordsTotal'] = $total;

        echo json_encode($return);
    }
    public function add(){
        $model = model("dict");
        if($model->createDict(input())){
            $data['url'] = url('Dict/index');
            $this->result($data, 1, '添加数据成功', 'json');
        }else{
            $error = $model->getError() ? $model->getError() : '添加数据失败';
            $this->result('', 0, $error, 'json');
        }
    }
    public function edit(){
        $model = model("dict");
        if($model->createDict(input())){
            $data['url'] = url('Dict/index');
            $this->result($data, 1, '修改数据成功', 'json');
        }else{
            $error = $model->getError() ? $model->getError() : '修改数据失败';
            $this->result('', 0, $error, 'json');
        }
    }
    public function find(){
        $id = $this->request->param('id/d', 0);
        $model = model("dict");
        $info = $model->getDictInfoById($id);
        if(!empty($info)){
            $this->result($info, 1, '查看成功！', 'json');
        }else{
            $error = $sheet->getError() ? $sheet->getError() : '查看失败!';
            $this->result('', 0, $error, 'json');
        }
    }
    public function stop(){
        $id = $this->request->param('id/d', 0);
        $model = model('dict');
        if($model->stopDict($id)){
            $this->result('', 1, '停止成功！', 'json');
        }else{
            $error = $model->getError() ? $model->getError() : '停止失败!';
            $this->result('', 0, $error, 'json');
        }
    }
    public function start(){
        $id = $this->request->param('id/d', 0);
        $model = model('dict');
        if($model->startDict($id)){
            $this->result('', 1, '开启成功！', 'json');
        }else{
            $error = $model->getError() ? $model->getError() : '开启失败!';
            $this->result('', 0, $error, 'json');
        }
    }
}