<?php

namespace app\console\model;

use think\Model;

class Activity extends Model
{
    public function getActivityInfoById($id){
        $result = $this->where(['a_id' => $id])->find();
        return $result;
    }

    public function createActivity($data,$id){
        if(empty($data)){
            $this->error = '缺少活动数据';
            return false;
        }
        $data['content'] = $data['summernote'];
        //验证数据信息
        $validate = validate('Activity');
        $scene = isset($data['a_id']) ? 'edit' : 'add';
        if(!$validate->scene($scene)->check($data)){
            $error = $validate->getError();
            $this->error = $error;
            return false;
        }
        //开启事务
        $this->startTrans();
        try{
			if($id == 1){
				$data['create_time'] = time();
                $time = date('Y-m-d H:i' , time());
                if($time > $data['start_time']){
                    $data['status'] = 1;
                } else {
                    $data['status'] = 4;
                }
                $this->allowField(true)->save($data);
			}else{
				if(isset($data['a_id'])){
					$time = date('Y-m-d H:i' , time());
					if($time > $data['start_time']){
						$data['status'] = 1;
					} else {
						$data['status'] = 0;
					}
					//$this->where(['a_id'=> $data['a_id']])->update($data);
					$aa = $this->where(['a_id' => $data['a_id']])->update(['status' => $data['status']]);
				} else {
					$data['create_time'] = time();
					$time = date('Y-m-d H:i' , time());
					if($time > $data['start_time']){
						$data['status'] = 1;
					} else {
						$data['status'] = 0;
					}
					$this->allowField(true)->save($data);
				}
			}
            
            // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
    public function stopActivity($id){
        if(empty($id)){
            $this->error = '该活动id不存在';
            return false;
        }
        //开启事务
        $this->startTrans();
        try{
            $this->where(['a_id' => $id])->update(['is_use' => -1]);
            // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
    public function startActivity($id){
        if(empty($id)){
            $this->error = '该活动id不存在';
            return false;
        }
        //开启事务
        $this->startTrans();
        try{
            $this->where(['a_id' => $id])->update(['is_use' => 1]);
            // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
    public function stopActivitySign($id){
        if(empty($id)){
            $this->error = '该活动id不存在';
            return false;
        }
        //开启事务
        $this->startTrans();
        try{
            $this->where(['a_id' => $id])->update(['is_sign_up' => -1]);
            // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
    public function startActivitySign($id){
        if(empty($id)){
            $this->error = '该活动id不存在';
            return false;
        }
        //开启事务
        $this->startTrans();
        try{
            $this->where(['a_id' => $id])->update(['is_sign_up' => 1]);
            // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
    public function showActivityDisabled($id){
        if(empty($id)){
            $this->error = '该活动id不存在';
            return false;
        }
        //开启事务
        $this->startTrans();
        try{
            $this->where(['a_id' => $id])->update(['is_show' => -1]);
            // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
}