<?php

namespace app\console\model;

use think\Model;

class Dict extends Model
{
    public function getDictInfoById($id){
        if(empty($id)){
            $this->error = '该数据id不存在';
            return false;
        }
        $info = $this->where(['id' => $id])->find();
        return $info;
    }
    public function getDictByType($str = ''){
        if($str == ''){
            $this->error = '该数据类型名称不存在';
            return false;;
        }
        $result = $this->alias("d")
                ->join("dict_type dt" , "d.dt_id=dt.dt_id")
                ->where(['dt.sign' => $str])
                ->order('d.list_order asc')
                ->select();
        return $result;
    }

    public function createDict($data){
        if(empty($data)){
            $this->error = '缺少相关数据';
            return false;
        }
        //验证数据信息
        $validate = validate('Dict');
        $scene = isset($data['id']) ? 'edit' : 'add';
        if(!$validate->scene($scene)->check($data)){
            $error = $validate->getError();
            $this->error = $error;
            return false;
        }

        //开启事务
        $this->startTrans();
        try{
            if(isset($data['id'])){
                if(empty($data['id'])){
                    $this->error = '该数据id错误';
                    return false;
                }
                $arr = [];
                $arr['dt_id'] = $data['type'];
                $arr['value'] = $data['value'];
                $arr['des'] = $data['des'];
                $arr['list_order'] = $data['list_order'];
                $this->where(['id' => $data['id']])->update($arr);
            } else {
                $info = \app\console\service\User::getInstance()->getInfo();
                $arr = [];
                $arr['dt_id'] = $data['type'];
                $arr['value'] = $data['value'];
                $arr['des'] = $data['des'];
                $arr['list_order'] = $data['list_order'];
                $arr['create_time'] = time();
                $arr['create_uid'] = $info['uid'];
                $arr['status'] = 1;
                $this->allowField(true)->save($arr);
            }
            // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
    public function stopDict($id){
        if(empty($id)){
            $this->error = '该数据id不存在';
            return false;
        }
        //开启事务
        $this->startTrans();
        try{
            $this->where(['id' => $id])->update(['status' => -1]);
            // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
    public function startDict($id){
        if(empty($id)){
            $this->error = '该数据id不存在';
            return false;
        }
        //开启事务
        $this->startTrans();
        try{
            $this->where(['id' => $id])->update(['status' => 1]);
            // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
}