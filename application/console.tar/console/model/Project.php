<?php

namespace app\console\model;

use think\Model;
use sys\Wechat;

class Project extends Model
{
    public function getProjectInfoById($id){
        if(empty($id)){
            $this->error = '该项目id不存在';
            return false;
        }
        $result = $this->where(['pro_id' => $id])->find();
        return $result;
    }
    public function setProjectStatus($id , $status){
        if(empty($id)){
            $this->error = '该项目id不存在';
            return false;
        }
        if(!is_numeric($status)){
            $this->error = '项目状态不为整数';
            return false;
        }
        $data = [];
        $data['status'] = $status;
        $result = $this->where(['pro_id' => $id])->update($data);
        return $result;
    }
    public function setProjectOrderList($data){
        if(empty($data)){
            $this->error = '缺少相关数据';
            return false;
        }
        //验证数据信息
        $validate = validate('ProjectHot');
        $scene = isset($data['id']) ? 'edit' : 'add';
        if(!$validate->scene($scene)->check($data)){
            $error = $validate->getError();
            $this->error = $error;
            return false;
        }
        //开启事务
        $this->startTrans();
        try{
            $this->where(['pro_id' => $data['id']])->update(['list_order' => $data['list_order']]);
            // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
    public function createProjectDraft($data){
        if(empty($data)){
            $this->error = '项目信息不存在';
            return false;
        }
        //开启事务
        $this->startTrans();
        try{
            $img = explode(',' , trim($data['enterprise_url'], ','));
            $material = '';
            foreach ($img as $key => $value) {
                $arr = explode('-', $value);
                $material .= $arr[0].',';
            }
            $data['enterprise_url'] = trim($material, ',');
            $img = explode(',' , trim($data['company_url'], ','));
            $material = '';
            foreach ($img as $key => $value) {
                $arr = explode('-', $value);
                $material .= $arr[0].',';
            }
            $data['company_url'] = trim($material, ',');
            $img = explode(',' , trim($data['product_url'], ','));
            $material = '';
            foreach ($img as $key => $value) {
                $arr = explode('-', $value);
                $material .= $arr[0].',';
            }
            $data['product_url'] = trim($material, ',');
            $img = explode(',' , trim($data['analysis_url'], ','));
            $material = '';
            foreach ($img as $key => $value) {
                $arr = explode('-', $value);
                $material .= $arr[0].',';
            }
            $data['analysis_url'] = trim($material, ',');
            if(isset($data['pro_id'])){
                $data['inc_industry'] = trim($data['inc_industry'], ',');
                $data['inc_area'] = trim($data['inc_area'], ',');
                $data['inc_sign'] = trim($data['inc_sign'], ',');
                $data['build_time'] = strtotime($data['build_time']);
                $data['last_time'] = time();
                $this->allowField(true)->save($data ,['pro_id' => $data['pro_id']]);
            } else {
                $info = \app\console\service\User::getInstance()->getInfo();
                $system = model("SystemConfig")->getSystemConfigInfo();
                $data['inc_industry'] = trim($data['inc_industry'], ',');
                $data['inc_area'] = trim($data['inc_area'], ',');
                $data['inc_sign'] = trim($data['inc_sign'], ',');
                $data['build_time'] = strtotime($data['build_time']);
                $data['create_time'] = time();
                $data['last_time'] = time();
                $data['create_uid'] = $info['uid'];
                $data['status'] = 1;
                $this->allowField(true)->save($data);
                $id = $this->getLastInsID();
                $result = createProEditQrcodeDirection($system['current'] , 'project' , $id , '' , '');
                if(!$result){
                    $this->error = '创建二维码指向失败';
                    return false;
                } else {
                    $this->where(['pro_id' => $id])->update(['qr_code' => $result]);
                }
            }
            // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
    public function createBoutiqueProject($id){
        if(empty($id)){
            $this->error = '大宗转让项目不存在';
            return false;
        }
        //开启事务
        $this->startTrans();
        try{
            $info = model("ZryxesEffect")->getZryxesEffectInfoById($id);
            $info1 = $this->where(['stock_code' => $info['neeq']])->find();
            if(empty($info1)){
                model("ZryxesEffect")->where(['id' => $id])->update(['boutique' => 1]);
                $user = \app\console\service\User::getInstance()->getInfo();
                $system = model("SystemConfig")->getSystemConfigInfo();
                $arr = [];
                $arr['pro_name'] = $info['sec_uri_tyshortname'];
                $arr['stock_code'] = $info['neeq'];
                $arr['stock_name'] = $info['sec_uri_tyshortname'];
                $arr['inc_sign'] = 15;
                $arr['capital_plan'] = 5;
                if($info['trademethod'] == '协议'){
                    $arr['transfer_type'] = 7;
                } else {
                    $arr['transfer_type'] = 8;
                }
                if($info['sublevel'] == '基础层'){
                    $arr['hierarchy'] = 10;
                } else {
                    $arr['hierarchy'] = 9;
                }
                $arr['contacts'] = $info['name'];
                if($info['contact'] == '电话'){
                    $arr['contacts_tel'] = $info['accountment'];
                }
                $arr['create_time'] = time();
                $arr['last_time'] = time();
                $arr['create_uid'] = $user['uid'];
                $arr['status'] = 1;
                $this->allowField(true)->save($arr);
                $id = $this->getLastInsID();
                $result = createProEditQrcodeDirection($system['current'] , 'project' , $id , '' , '');
                if(!$result){
                    $this->error = '创建二维码指向失败';
                    return false;
                } else {
                    $this->where(['pro_id' => $id])->update(['qr_code' => $result]);
                }
            } else {
                $this->error = '该股票代码已有项目';
                return false;
            }
            // 提交事务
            $this->commit();
            return $id;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
    public function createProject($data){
        if(empty($data)){
            $this->error = '缺少相关数据';
            return false;
        }
        //验证数据信息
        $validate = validate('Project');
        $scene = isset($data['pro_id']) ? 'edit' : 'add';
        if(!$validate->scene($scene)->check($data)){
            $error = $validate->getError();
            $this->error = $error;
            return false;
        }

        //开启事务
        $this->startTrans();
        try{
            $img = explode(',' , trim($data['enterprise_url'], ','));
            $material = '';
            foreach ($img as $key => $value) {
                $arr = explode('-', $value);
                $material .= $arr[0].',';
            }
            $data['enterprise_url'] = trim($material, ',');
            $img = explode(',' , trim($data['company_url'], ','));
            $material = '';
            foreach ($img as $key => $value) {
                $arr = explode('-', $value);
                $material .= $arr[0].',';
            }
            $data['company_url'] = trim($material, ',');
            $img = explode(',' , trim($data['product_url'], ','));
            $material = '';
            foreach ($img as $key => $value) {
                $arr = explode('-', $value);
                $material .= $arr[0].',';
            }
            $data['product_url'] = trim($material, ',');
            $img = explode(',' , trim($data['analysis_url'], ','));
            $material = '';
            foreach ($img as $key => $value) {
                $arr = explode('-', $value);
                $material .= $arr[0].',';
            }
            $data['analysis_url'] = trim($material, ',');
            if(isset($data['pro_id'])){
                $arr = [];
                $arr = $data;
                $arr['inc_industry'] = trim($data['inc_industry'], ',');
                $arr['inc_area'] = trim($data['inc_area'], ',');
                $arr['inc_sign'] = trim($data['inc_sign'], ',');
                $arr['build_time'] = strtotime($data['build_time']);
                $arr['last_time'] = time();
                $arr['status'] = 2;
                $this->allowField(true)->save($arr , ['pro_id' => $data['pro_id']]);
            } else {
                $info = \app\console\service\User::getInstance()->getInfo();
                $system = model("SystemConfig")->getSystemConfigInfo();
                $data['inc_industry'] = trim($data['inc_industry'], ',');
                $data['inc_area'] = trim($data['inc_area'], ',');
                $data['inc_sign'] = trim($data['inc_sign'], ',');
                $data['build_time'] = strtotime($data['build_time']);
                $data['create_time'] = time();
                $data['last_time'] = time();
                $data['create_uid'] = $info['uid'];
                $data['status'] = 2;
                $this->allowField(true)->save($data);
                $id = $this->getLastInsID();
                $result = createProEditQrcodeDirection($system['current'] , 'project' , $id , '' , '');
                if(!$result){
                    $this->error = '创建二维码指向失败';
                    return false;
                } else {
                    $this->where(['pro_id' => $id])->update(['qr_code' => $result]);
                }
            }
            // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
    public function stopProject($id){
        //开启事务
        $this->startTrans();
        try{
            $this->where(['pro_id' => $id])->update(['flag' => -1]);
            // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
    public function startProject($id){
        //开启事务
        $this->startTrans();
        try{
            $this->where(['pro_id' => $id])->update(['flag' => 1]);
            // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
    public function sendProjectInfo($id){
        //开启事务
        $this->startTrans();
        try{
            $info = $this->where(['pro_id' => $id])->find();
            $list = model("Member")->select();
            $model = model("dict");
            $industry = explode(',', $info['inc_industry']);
            $inc_industry = '';
            foreach ($industry as $key => $value) {
                $dict = $model->getDictInfoById($value);
                $inc_industry .= $dict['value'].' , ';
            }
            $info['inc_industry'] = trim($inc_industry , ' , ');
            $array = [
                'first' => ['value' => '您好，您有一个新项目上线!' , 'color' => '#173177'],
                'keyword1' => ['value' => $info['contacts'].'【手机:'.$info['contacts_tel'].'】【邮箱:'.$info['contacts_email'].'】' , 'color' => '#0D0D0D'],
                'keyword2' => ['value' => $info['pro_name'] , 'color' => '#0D0D0D'],
                'keyword3' => ['value' => $info['introduction'] , 'color' => '#0D0D0D'],
                'keyword4' => ['value' => $info['inc_industry'] , 'color' => '#0D0D0D'],
                'keyword5' => ['value' => $info['need'] , 'color' => '#0D0D0D'],
                'remark' => ['value' => '请点击详情查看!' , 'color' => '#173177'],
            ];
            $model = model('Send');
            $send_id = $model->addSendInfo(['content' => json_encode($array), 'type' => 'project', 'act_id' => $id]);
            foreach ($list as $key => $value) {
                $end = sendTemplateMessage(config("new_project"), $value['openId'], $_SERVER['SERVER_NAME'].'/home/project_info/index/id/'.$info['pro_id'], $array);
                $end = getSendCodeMsg($end);
                $result = explode('-', $end);
                $result = $result[0] == 0 ? 'true' : 'false';
                $ars = ['userName' => $value['userName'], 'openId' => $value['openId'], 'send_id' => $send_id, 'content' => $end, 'result' => $result];
                model('SendList')->addSendListInfo($ars);
//                if(!$end){
//                    $this->error .= $value['uid'];
////                    return false;
//                }
            }
            // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
}