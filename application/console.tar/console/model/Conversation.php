<?php

namespace app\console\model;

use think\Model;

class Conversation extends Model
{
    
}