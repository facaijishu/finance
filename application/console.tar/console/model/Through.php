<?php

namespace app\console\model;

use think\Model;

class Through extends Model
{
    public function getThroughInfoById($id){
        $result = $this->alias("t")
                ->join("Member m" , "t.uid=m.uid")
                ->where(['t.t_id' => $id])
                ->field("t.*,m.superior,m.uid")
                ->find();
        $result['createTime'] = date('Y-m-d H:i:s' , $result['createTime']);
        $result['superior'] = $result['superior'] == 0 ? '暂无' : $result['superior'];
        if($result['superior'] != 0){
            $info = $this->where(['uid' => $result['superior']])->find();
            $result['superior'] = $info['realName'];
        }
        if($result['status'] == 0){
            $result['status_des'] = '未审核';
        }elseif ($result['status'] == -1) {
            $result['status_des'] = '审核失败';
        } else {
            $result['status_des'] = '已审核';
        }
        if($result['status'] == 1){
            $num = [];
            $model = model("Member");
            $all = $model->where(['superior' => $result['uid']])->select();
            $a = $this->getStatisticsData($all);
            $a_num = count($all);
            $time = date('Y-m' , time());
            $now = $model->where('CREATE_TIME','like',$time.'%')->where(['superior' => $result['uid']])->select();
            $b = $this->getStatisticsData($now);
            $b_num = count($now);
            $time = date('Y-m' , strtotime('-1 month'));
            $prev = $model->where('CREATE_TIME','like',$time.'%')->where(['superior' => $result['uid']])->select();
            $c = $this->getStatisticsData($prev);
            $c_num = count($prev);
            $time = date('Y-m-d' , strtotime('-1 day'));
            $yesterday = $model->where('CREATE_TIME','like',$time.'%')->where(['superior' => $result['uid']])->select();
            $d = $this->getStatisticsData($yesterday);
            $d_num = count($yesterday);
            $num = [['游客',$a[0],$c[0],$b[0],$d[0]] , ['绑定用户',$a[1],$c[1],$b[1],$d[1]] , ['认证合伙人',$a[2],$c[2],$b[2],$d[2]] , ['合计',$a_num,$c_num,$b_num,$d_num]];
            $result['num'] = $num;
        }
        $model = model("ThroughDefaultInfo");
        $reason = $model->where(['uid' => $result['uid']])->select();
        $model = model("User");
        foreach ($reason as $key => $value) {
            $user = $model->getUserById($value['create_uid']);
            $reason[$key]['create_user'] = $user['real_name'];
        }
        $result['reason'] = $reason;
        return $result;
    }
    public function setThroughSuccess($id){
        //开启事务
        $this->startTrans();
        try{
            $data = [];
            $data['throughTime'] = time();
            $data['THROUGH_TIME'] = date('Y-m-d H:i:s' , time());
            $data['status'] = 1;
            $this->where(['t_id' => $id])->update($data);
            $info = $this->where(['t_id' => $id])->find();
            model("Member")->where(['uid' => $info['uid']])->update(['userType' => 2]);
            
            $admin = \app\console\service\User::getInstance()->getInfo();
            $arr['uid'] = $info['uid'];
            $arr['reason'] = '认证成功';
            $arr['create_time'] = time();
            $arr['create_uid'] = $admin['uid'];
            model("ThroughDefaultInfo")->allowField(true)->save($arr);
            $info = model("Member")->where(['uid' => $info['uid']])->find();
            //合伙人审核通过通知
            $userinfo = model("Member")->where(['uid' => $info['uid']])->find();
            //添加integral_record认证时间
            $integral_record = model("IntegralRecord")->where(['openId' => $userinfo['openId']])->find();
            if($integral_record['through'] == ''){
                model("IntegralRecord")->where(['openId' => $userinfo['openId']])->update(['through' => $data['THROUGH_TIME']]);
            }
            $array = [
                'first' => ['value' => '您好，你的金融合伙人审核请求已通过，欢迎使用。' , 'color' => '#173177'],
                'keyword1' => ['value' => $userinfo['realName'] , 'color' => '#0D0D0D'],
                'keyword2' => ['value' => $userinfo['userPhone'] , 'color' => '#0D0D0D'],
                'keyword3' => ['value' => date('Y-m-d H:i:s' , time()) , 'color' => '#0D0D0D'],
                'remark' => ['value' => '更多精彩项目尽在FA財' , 'color' => '#173177'],
            ];
            $end = sendTemplateMessage(config("register_examine"), $userinfo['openId'], $_SERVER['SERVER_NAME'].'/home/plat_form/index', $array);
            if(!$end){
                $this->error = '模板消息发送失败';
                return false;
            }
            //推荐用户的审核通知
            if($userinfo['superior'] != 0){
                $userinfo1 = model("Member")->where(['uid' => $userinfo['superior']])->find();
                $array1 = [
                    'first' => ['value' => 'FA財有新的金融合伙人加入!' , 'color' => '#173177'],
                    'keyword1' => ['value' => $userinfo1['realName'] , 'color' => '#0D0D0D'],
                    'keyword2' => ['value' => $userinfo['realName'] , 'color' => '#0D0D0D'],
                    'remark' => ['value' => '感谢您的推荐，查看推荐奖励详情请进' , 'color' => '#173177'],
                ];
                $end1 = sendTemplateMessage(config("recommend_success"), $userinfo1['openId'], $_SERVER['SERVER_NAME'].'/home/my_center/index', $array1);
                if(!$end1){
                    $this->error = '模板消息发送失败';
                    return false;
                }
            }
            // 提交事务
            $this->commit();
            return $info;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
    public function getStatisticsData($data){
        if(empty($data)){
            $a = 0;$b = 0;$c = 0;
        } else {
            $a = 0;$b = 0;$c = 0;
            foreach ($data as $key => $value) {
                if($value['userType'] == 0){
                    $a++;
                }elseif ($value['userType'] == 1) {
                    $b++;
                } else {
                    $c++;
                }
            }
        }
        $arr = [$a , $b , $c];
        return $arr;
    }
    public function setThroughStop($id){
        //开启事务
        $this->startTrans();
        try{
            $data = [];
            $data['flag'] = -1;
            $this->where(['t_id' => $id])->update($data);
            // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
    public function setThroughStart($id){
        //开启事务
        $this->startTrans();
        try{
            $data = [];
            $data['flag'] = 1;
            $this->where(['t_id' => $id])->update($data);
            // 提交事务
            $this->commit();
            return true;
        } catch (\Exception $e) {
            // 回滚事务
            $this->rollback();
            return false;
        }
    }
}